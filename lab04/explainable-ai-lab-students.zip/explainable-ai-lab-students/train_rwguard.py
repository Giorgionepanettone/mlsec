"""
    Train the Rwguard process monitor component based on Random Forests
"""
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from joblib import dump
from sklearn import metrics
import csv


"""
Load the train and testing dataset. Pay attention you have them already split up in two files!
You can load the data either using the csv library or pandas whichever you prefer
The feature names are in this order Read, write, open, close, fast read, fast write, fast close, fast open, label - since they are in different files you do not even need the label you can build the targets (train and test_y) using numerical values like 0 for one class and 1 for the other
"""

benign_train_x = []
benign_train_y = []

ransomware_train_x = []
ransomware_train_y = []

benign_test_x = []
benign_test_y = []

ransomware_test_x = []
ransomware_test_y = []


# you can play with the number of estimators and tree max depth parameter to build and then explain different models. select n_jobs at lest 2 less than the number of you CPU cores
clf = RandomForestClassifier(n_estimators=100, verbose=1, max_depth=100, n_jobs=5) #https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html

train_x = []
train_y = []

clf.fit(train_x, train_y)

dump(clf, 'rwguard_model.joblib') # using joblib to save the model for later load and use, there are other ways to store/load models


#evaluate the model here on the test data and print performance metrics. See sklearn documentation https://scikit-learn.org/stable/api/sklearn.metrics.html
test_x = [] 
y_pred = clf.predict(test_x)

print("Accuracy:", metrics.accuracy_score(np.concatenate((test_y, y_pred)) # pay attention to the ordering


